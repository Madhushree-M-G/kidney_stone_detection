# KidneyStoneDetection
Performing various image enhancement techniques and segmentation on ultrasound image of the kidney to detect kidney stone. First, Otsu thresholding is used to identify the region of interest, then image is enhanced by using various filters. Finally, image segmentation is applied to locate the stone.
